const gt = (a) => {
    var total = 1;
    for (let i = 1; i <= a; i++) {

        total = total * i;


    }
    console.log(total);
};

gt(5);
gt(6);